package TrainingOOP;

import java.util.ArrayList;
import java.util.List;

public class GSM
{
	// Fields
	private String gsmModel;
	private String gsmManufacture;
	private double gsmPrice;
	private String gsmOwner;
	private static GSM iPhone4S;

	// Constructors
	public GSM(String gsmModel, String gsmManufacture, double gsmPrice, String gsmOwner)
	{
		this.gsmModel = gsmModel;
		this.gsmManufacture = gsmManufacture;
		this.gsmPrice = gsmPrice;
		this.gsmOwner = gsmOwner;
	}

	public static void GSM()
	{
		iPhone4S = new GSM("iPhone 4S", "Apple", 2000.11, "Dimitar");
	}

	// Properties
	public String getGsmModel()
	{
		return gsmModel;
	}

	public void setGsmModel(String gsmModel)
	{
		this.gsmModel = gsmModel;
	}

	public String getGsmManufacture()
	{
		return gsmManufacture;
	}

	public void setGsmManufacture(String gsmManufacture)
	{
		this.gsmManufacture = gsmManufacture;
	}

	public double getGsmPrice()
	{
		return gsmPrice;
	}

	public void setGsmPrice(double gsmPrice)
	{
		this.gsmPrice = gsmPrice;
	}

	public String getGsmOwner()
	{
		return gsmOwner;
	}

	public void setGsmOwner(String gsmOwner)
	{
		this.gsmOwner = gsmOwner;
	}

	public static GSM getiPhone4S()
	{
		return iPhone4S;
	}

	public static void setiPhone4S(GSM iPhone4S)
	{
		GSM.iPhone4S = iPhone4S;
	}

	// Add property Call history
	public List<Call> CallHistory = new ArrayList<Call>();

	// Methods
	@Override
	public String toString()
	{
		return "GSM Model=" + gsmModel + ", \tManufacture=" + gsmManufacture + ",\t Price=" + gsmPrice + ", \tOwner="
				+ gsmOwner;
	}

	public void AddCalls(String dateTime, String dialedNumber, int duration)
	{
		Call call = new Call(dateTime, dialedNumber, duration);
		CallHistory.add(call);
	}

	// public void DeleteCalls(int duration)
	// {
	//
	// for (int i = 0; i < CallHistory.size(); i++)
	// {
	// if (CallHistory.get(i).getDuration() == duration)
	// {
	// CallHistory.remove(i);
	// i--;
	// }
	//
	// }
	//
	// }

	public void RemoveLongestCall()
	{
		int duration = 0;
		int index = 0;
		for (int i = 0; i < CallHistory.size(); i++)
		{

			if (CallHistory.get(i).getDuration() > duration)
			{
				duration = CallHistory.get(i).getDuration();
				index = i;
			}
		}
		CallHistory.remove(index);
	}

	public void ClearCalls()
	{
		CallHistory.clear();
	}

	public void CalculateTotal(double pricePerMin)
	{
		double time = 0;
		for (int i = 0; i < CallHistory.size(); i++)
		{
			time += CallHistory.get(i).getDuration();
		}
		double price = (time / 60) * pricePerMin;
		System.out.printf("\nTotal price of the calls: +%f", price);
	}

	public void DisplayCalls()
	{
		for (int i = 0; i < CallHistory.size(); i++)
		{
			System.out.printf("Date and Time: %s\tDialed phone number: %s\tDuration: %d\n",
					CallHistory.get(i).getDateTime(), CallHistory.get(i).getDialedNumber(),
					CallHistory.get(i).getDuration());
		}
	}
}
