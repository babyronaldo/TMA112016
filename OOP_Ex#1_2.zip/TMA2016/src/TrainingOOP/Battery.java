package TrainingOOP;

public class Battery
{
	// Enumeration
	public enum BatteryType
	{
		LiIon, NiMH, NiCd
	}

	// Fields
	private BatteryType batteryModel;
	private int batteryHoursIdle;
	private int batteryHoursTalk;

	// Constructors
	public Battery(BatteryType batteryModel, int batteryHoursIdel, int batteryHoursTalk)
	{
		this.batteryModel = batteryModel;
		this.batteryHoursIdle = batteryHoursIdel;
		this.batteryHoursTalk = batteryHoursTalk;
	}

	// Properties
	public BatteryType getBatteryModel()
	{
		return batteryModel;
	}

	public void setBatteryModel(BatteryType batteryModel)
	{
		this.batteryModel = batteryModel;
	}

	public int getBatteryHoursIdle()
	{
		return batteryHoursIdle;
	}

	public void setBatteryHoursIdle(int batteryHoursIdle)
	{
		this.batteryHoursIdle = batteryHoursIdle;
	}

	public int getBatteryHoursTalk()
	{
		return batteryHoursTalk;
	}

	public void setBatteryHoursTalk(int batteryHoursTalk)
	{
		this.batteryHoursTalk = batteryHoursTalk;
	}

}
