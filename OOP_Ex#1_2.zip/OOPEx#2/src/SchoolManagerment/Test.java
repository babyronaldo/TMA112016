package SchoolManagerment;

public class Test
{
	public static void main(String[] args)
	{
		Students s = new Students("Abc", "Xyz", 12);
		s.AddComment("the day you went away???");

		Discipline ma = new Discipline("Mathematics", 2, 2);
		ma.AddComment("1+1=2");
		Discipline ph = new Discipline("Physics", 8, 4);
		Discipline cm = new Discipline("Chemistry", 3, 2);
		Discipline ec = new Discipline("Economy", 1, 1);
		// Teachers cl = new Teachers("Bill", "Clinton",List<Discipline>());
		s.PrintComment();
	}
}
