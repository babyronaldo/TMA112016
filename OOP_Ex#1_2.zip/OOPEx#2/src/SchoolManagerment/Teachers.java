package SchoolManagerment;

import java.util.*;

public class Teachers extends Person
{
	private List<Discipline> discipline;

	public Teachers(String firstName, String lastName, List<Discipline> discipline)
	{
		super(firstName, lastName);
		this.discipline = discipline;
	}

	public List<Discipline> getDiscipline()
	{
		return discipline;
	}

	public void setDiscipline(List<Discipline> discipline)
	{
		this.discipline = discipline;
	}

}
