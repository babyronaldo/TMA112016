package SchoolManagerment;

import java.util.ArrayList;
import java.util.List;

public class Comments
{
	// Fields
	private List<String> InputComment;// = new ArrayList<String>();

	// Constructor
	public Comments()
	{
		this.InputComment = new ArrayList<String>();
	}

	public List<String> getInputComment()
	{
		return InputComment;
	}

	public void setInputComment(List<String> inputComment)
	{
		InputComment = inputComment;
	}

	public void AddComment(String inputComment)
	{
		InputComment.add(inputComment);
	}

	public void PrintComment()
	{
		for (String e : InputComment)
		{
			System.out.println("Comment: " + e);
		}
	}
}
