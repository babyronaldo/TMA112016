package SchoolManagerment;

public class Discipline extends Comments
{
	private String disciplineName;
	private int numberOfExercises;
	private int numberOfLectures;

	public Discipline(String disciplineName, int numberOfExercises, int numberOfLectures)
	{
		this.disciplineName = disciplineName;
		this.numberOfExercises = numberOfExercises;
		this.numberOfLectures = numberOfLectures;
	}

	public String getDisciplineName()
	{
		return disciplineName;
	}

	public void setDisciplineName(String disciplineName)
	{
		this.disciplineName = disciplineName;
	}

	public int getNumberOfExercises()
	{
		return numberOfExercises;
	}

	public void setNumberOfExercises(int numberOfExercises)
	{
		this.numberOfExercises = numberOfExercises;
	}

	public int getNumberOfLectures()
	{
		return numberOfLectures;
	}

	public void setNumberOfLectures(int numberOfLectures)
	{
		this.numberOfLectures = numberOfLectures;
	}

	// @Override
	// public String toString()
	// {
	// return "Discripline [DiscriplineName=" + disciplineName + ",
	// NumberOfExercises=" + numberOfExercises
	// + ", NumberOfLectures=" + numberOfLectures + "]";
	// }

}
