package SchoolManagerment;

public class Students extends Person
{
	// private String Name;
	private int ClassNumber;
	// private String Teachers;

	public Students(String firstName, String lastName, int classNumber)
	{
		super(firstName, lastName);
		this.ClassNumber = classNumber;
	}

	public int getClassNumber()
	{
		return ClassNumber;
	}

	public void setClassNumber(int classNumber)
	{
		ClassNumber = classNumber;
	}

}
