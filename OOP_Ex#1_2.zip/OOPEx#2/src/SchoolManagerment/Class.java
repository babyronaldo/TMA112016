package SchoolManagerment;

import java.util.List;

public class Class extends Comments
{
	private String ClassID;
	private List<Students> students;
	private List<Teachers> teachers;

	public Class(List<Students> students, List<Teachers> teachers, String classID)
	{
		this.ClassID = classID;
		this.students = students;
		this.teachers = teachers;
	}

	public String getClassID()
	{
		return ClassID;
	}

	public void setClassID(String classID)
	{
		ClassID = classID;
	}

	public List<Students> getStudents()
	{
		return students;
	}

	public void setStudents(List<Students> students)
	{
		this.students = students;
	}

	public List<Teachers> getTeachers()
	{
		return teachers;
	}

	public void setTeachers(List<Teachers> teachers)
	{
		this.teachers = teachers;
	}

	@Override
	public String toString()
	{
		return "Class:\t ClassID=" + ClassID + ", students=" + students + ", teachers=" + teachers;
	}

}
