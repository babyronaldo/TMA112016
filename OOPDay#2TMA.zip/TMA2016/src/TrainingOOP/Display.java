package TrainingOOP;

public class Display
{
	private double displaySize;
	private String displayCorlors;

	public Display(double displaySize, String displayCorlors)
	{
		this.displaySize = displaySize;
		this.displayCorlors = displayCorlors;
	}

	public double getDisplaySize()
	{
		return displaySize;
	}

	public void setDisplaySize(double displaySize)
	{
		this.displaySize = displaySize;
	}

	public String getDisplayCorlors()
	{
		return displayCorlors;
	}

	public void setDisplayCorlors(String displayCorlors)
	{
		this.displayCorlors = displayCorlors;
	}

}
