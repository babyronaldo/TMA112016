package TrainingOOP;

public class GSMCallHistoryTest
{
	public static void main(String[] args)
	{
		GSM[] array = new GSM[3];

		GSM firstGSM = new GSM("iPhone 7", "Apple", 649.00, "Steve Gates");
		array[0] = firstGSM;

		GSM secondGSM = new GSM("Galaxy 7Edge", "Samsung", 579.99, "Toyota Honda");
		array[1] = secondGSM;

		GSM thirdGSM = new GSM("Google Pixel", "Google", 849.99, "Lary Page");
		array[2] = thirdGSM;

		// Information about GSMs in the array
		for (int i = 0; i < array.length; i++)
		{
			System.out.println(array[i].toString());
		}

		// Information in the static property
		GSM.GSM();
		System.out.println(GSM.getiPhone4S().toString());

		// defining instance of GSM class
		GSM fourthGSM = new GSM("Galayxy Note7", "Samsung", 645.99, "Donal Trump");

		// Add calls and display
		System.out.println("\nAdd calls and display: ");
		fourthGSM.AddCalls("20/11/2016", "0975850880", 67);
		fourthGSM.AddCalls("20/11/2016", "0974836124", 35);
		fourthGSM.AddCalls("20/11/2016", "0987233419", 82);
		fourthGSM.AddCalls("20/11/2016", "0934867491", 26);
		fourthGSM.DisplayCalls();

		// Delete call and display
		System.out.println("\nDelete longest call and display again: ");
		fourthGSM.RemoveLongestCall();
		fourthGSM.DisplayCalls();

		// Total price
		fourthGSM.CalculateTotal(0.37);

		// Clear calls and display
		fourthGSM.ClearCalls();
		fourthGSM.DisplayCalls();
	}
}
