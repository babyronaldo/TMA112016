package TrainingOOP;

public class Call
{
	private String dateTime;
	private String dialedNumber;
	private int duration;

	public Call(String dateTime, String dialedNumber, int duration)
	{
		this.dateTime = dateTime;
		this.dialedNumber = dialedNumber;
		this.duration = duration;
	}

	public String getDateTime()
	{
		return dateTime;
	}

	public void setDateTime(String dateTime)
	{
		this.dateTime = dateTime;
	}

	public String getDialedNumber()
	{
		return dialedNumber;
	}

	public void setDialedNumber(String dialedNumber)
	{
		this.dialedNumber = dialedNumber;
	}

	public int getDuration()
	{
		return duration;
	}

	public void setDuration(int duration)
	{
		this.duration = duration;
	}

}
